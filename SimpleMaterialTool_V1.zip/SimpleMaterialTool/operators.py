import bpy
from . import utils

class MATERIAL_TOOLS_OT_DeleteDuplicateMaterials(bpy.types.Operator):
    bl_idname = "material_tools.delete_duplicate_materials"
    bl_label = "Delete Duplicate Materials"

    def execute(self, context):
        RemoveUnusedData.delete_duplicate_materials()
        return {'FINISHED'}

class MATERIAL_TOOLS_OT_DeleteUnusedUVMap(bpy.types.Operator):
    bl_idname = "material_tools.delete_unused_uv_map"
    bl_label = "Delete Unused UV Map"

    def execute(self, context):
        RemoveUnusedData.delete_unused_uv_map()
        return {'FINISHED'}

class MATERIAL_TOOLS_OT_RemoveUnusedMaterialSlots(bpy.types.Operator):
    bl_idname = "material_tools.remove_unused_material_slots"
    bl_label = "Remove Unused Material Slots"

    def execute(self, context):
        RemoveUnusedData.remove_unused_material_slots()
        return {'FINISHED'}

class MATERIAL_TOOLS_OT_RandomMaterial(bpy.types.Operator):
    bl_idname = "material_tools.random_material"
    bl_label = "Random Material"

    def execute(self, context):
        RandomMaterial.assign_random_material(context)
        return {'FINISHED'}

class MATERIAL_TOOLS_OT_AutoLinkTextures(bpy.types.Operator):
    bl_idname = "material_tools.auto_link_textures"
    bl_label = "Auto Link Texture Map"

    def execute(self, context):
        AutoLinkTexture.auto_link_textures()
        if context.scene.material_tools.delete_duplicate_textures:
            AutoLinkTexture.remove_duplicate_textures()
        return {'FINISHED'}